'use strict';

/**
 * teacher controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::teacher.teacher');
