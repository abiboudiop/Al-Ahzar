'use strict';

/**
 * subject service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::subject.subject');
